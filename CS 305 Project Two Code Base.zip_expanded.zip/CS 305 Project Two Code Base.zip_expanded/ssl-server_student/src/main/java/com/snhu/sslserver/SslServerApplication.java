package com.snhu.sslserver;

// for MessageDigest library
import java.security.MessageDigest;
// for NoSuchAlgorithmException library for exception handling
import java.security.NoSuchAlgorithmException;

// for Tomcat's HexUtils library to change hash to hex
import org.apache.tomcat.util.buf.HexUtils;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";

@RestController
class ServerController{
	// i. creating RESTful route using @RequestMapping method to 
	//    generate and return required info to secure web browser
    @RequestMapping("/project2")
    
    // adding exception handling for message digest 
    public String myHash() throws NoSuchAlgorithmException {
    	// ii. changed to reflect name of editor
    	String data = "Welcome to project 2 Medhawi Bista!";
       // iii. creating MessageDigest class object using java.security.MessageDigest library
       // initializing object w/ selected algorithm
    	MessageDigest firstMessage = MessageDigest.getInstance("SHA-256");
        
    	// v. using digest method to generate hash value of byte type from unique data string
    	// creating byte array and encoding our string into a byte array
    	byte[] newByteArray = firstMessage.digest(data.getBytes());
    	
    	// vi. converting hash value to hex
    	// using tomcat's utility function for alternative to btyesToHex function
    	String checksum = HexUtils.toHexString(newByteArray);

    	// vii. checksum print out (name and unique data string)
    	return "<p>data: "+data+"</p>"+ "<p>checksum: "+checksum+"</p>";
    
    }
}